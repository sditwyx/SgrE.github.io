%*************************************************************
%% Copyright (C).
%% All rights reserved.
%% Date: 05/2015

%%******************************************* Experimental Settings *********************************************%%
clc;
clear all;
%seq = [1:8,10,13,14,18,20,23,25,27,29,30,31,34,37:45];
seq1 = [1:5,8:11,14:17,19:25,27,29:32,35,37:40,42,43,44,47,49,51];
seq2 = [52:63,66:69,72:90,93:95,97,98,100];
seq = [seq1,seq2];
%seq = [1:5,8:11,14:17,19:25,27,29:32,35,37:40,42,43,44,47,49,51];
%mepath = ['E:\Reference\Tracking\Correlation Filters\KCF_PAMI\KCF_me\Functions\Results_û�вü�\'];
mepath = ['.\Results\Me5kcf\'];
a = 0;
cle100 = zeros(1,length(seq));
overlap100 = zeros(1,length(seq));
for s = 1:length(seq)
    s
init = ReadTrackingImgnew(seq(s));
title = init.name;
dataPath = init.path;                                                      % initial position and affine parameters
% num = init.length;
% load([ init.respath '\' title '_gt.mat']);
% 
load([mepath strcat(title,'_me5_rs','.mat')]);
%  [ centerRate ] = centerErrorEvaluation(me1CenterAll, gtCenterAll, frameIndex);

%  load([mepath strcat(title,'_kcf_','rs.mat')]);
%  [ centerRate ] = centerErrorEvaluation(kcfCenterAll, gtCenterAll, frameIndex);
cle100(s) = mean(centerRate);
overlap100(s) = mean(overlapRate);
a = a+fps;
    h=1;
    m = 0:50;
    for i = 0:50
        t=0;
        for j = 1:length(centerRate)
            if centerRate(j) < i
                t = t+1;
            end
        end
        cle(h,s)=t/length(centerRate);
        h = h+1;  
    end
    
    k=1;
    for i = 0:0.05:1
        t=0;
        for j = 1:length(overlapRate)
            if overlapRate(j)>i
                t = t+1;
            end
        end
        y(k,s)=t/length(overlapRate);
        k = k+1;
    end
end
center = mean(cle');
if size(cle,2)>1
    figure,plot(m,center,'Linewidth',4)
    text(35,0.3,['cle=',num2str(center(21))]);
else
    figure,plot(m,cle,'Linewidth',4)
    text(35,0.3,['cle=',num2str(cle(21))]);
end

x = 0:0.05:1;
overlaprate = mean(y');
if size(y,2)>1
    figure,plot(x,overlaprate,'Linewidth',4),hold on;
    text(0.75,0.1,['overlap=',num2str(mean(overlaprate))]);
else
    figure,plot(x,y,'Linewidth',4)
    text(0.75,0.1,['overlap=',num2str(mean(y))]);
end
