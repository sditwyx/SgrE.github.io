function [otsdf,X] = obtain_otsdf(A,label,sz)

for j = 1:size(A,2)
    im = normalize_image(reshape(A(:,j),sz(1),sz(2)));
    [l1,l2] = gradient(im);
    Y(:,:,1,j) = l1;
    Y(:,:,2,j) = l2;
    X(:,:,1,j) = im;
end

labels = label';
[labels,ind] = sort(labels,'descend');
X = X(:,:,:,ind);
Y = Y(:,:,:,ind);
[m,n,dim,num_img] = size(X);
args = [];
args.C = 1;
args.alpha = 1e-3;
args.beta = 1-args.alpha;
args.img_size = [m,n,dim];
args.dim = dim;
args.t_init = 100;
args.tolerance = 1e-8;
args.max_iter = 1e6;
args.batch_size = 2500;
args.psd_flag = 0;
args.fft_size = [m,n];
args.fft_mask = ones(args.fft_size(1),args.fft_size(2),dim);
args.fft_mask(1:m,1:n,:) = 0;
args.target_magnitude = 1;
args.target_sigma = 0.2;
data = X;

data_freq = fft2(data,args.fft_size(1),args.fft_size(2))/sqrt(prod(args.fft_size));
otsdf = build_otsdf(args,labels,data_freq,X);