function [H_pos] = multiHfiterPos(A_pos,pos_step,sz)
iteration_time = size(A_pos,2)/pos_step;
H_pos = [];
for k = 1:iteration_time
    labels = ones(1,pos_step);
    [otsdf_h,~] = obtain_otsdf(A_pos(:,((k-1)*pos_step+1):k*pos_step),labels,sz);
    w_pos = otsdf_h.filt;
    H_pos = [H_pos,w_pos(:)];
end