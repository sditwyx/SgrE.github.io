function [H_pos,H_neg] = multiHfiter(A_pos,A_neg,num_n,neg_step,pos_step,sz)
iteration_time = num_n/neg_step;
H_pos = [];H_neg = [];
X=[];
for k = 1:iteration_time
    labels = ones(1,pos_step);
    [otsdf_h,~] = obtain_otsdf(A_pos(:,((k-1)*pos_step+1):k*pos_step),labels,sz);
    w_pos = otsdf_h.filt;
    H_pos = [H_pos,w_pos(:)];
    %X = [X,X_temp];
    labels = -ones(1,neg_step);
    [otsdf_h,~] = obtain_otsdf(A_neg(:,((k-1)*neg_step+1):k*neg_step),labels,sz);
    w_neg = otsdf_h.filt;
    H_neg = [H_neg,w_neg(:)];
end