
clc;
clear all;
warning all;
addpath('./Affine Sample Functions');
addpath(genpath('./Evaluation'));
addpath('.\OTSDF_functions\');
addpath('.\kcf\');
%vl_setup;
init = ReadTrackingImgnewmix(29);
path = '.\seq\Trellis\';
ground_truth = load([path 'groundtruth_rect.txt']);
x = ground_truth(1,1) + ground_truth(1,3)/2;
y = ground_truth(1,2) + ground_truth(1,4)/2;%x,y,w,h
p = [x y ground_truth(1,3:4) 0];
dataPath = [path 'img\'];                                                      % initial position and affine parameters
rand('state',0);    randn('state',0);
%savepath=['.\Results\'];
opt  = struct('numsample',600,'affsig',[5,5,.02,.002,.005,.001]); 
kernel.type = 'hog';
features.gray = false;
features.hog = false;
padding = 1.5;  %extra area surrounding the target
lambda = 1e-4;  %regularization
output_sigma_factor = 0.1;  %spatial bandwidth (proportional to target)
interp_factor = 0.02;
PSRange = 0.6/(1+padding);

kernel.sigma = 0.5;

kernel.poly_a = 1;
kernel.poly_b = 9;

features.hog = true;
features.hog_orientations = 9;
cell_size = 4;

sz = [32 32]; 
target_sz = [ground_truth(1,4), ground_truth(1,3)];
window_sz = floor(target_sz * (1 + padding));
output_sigma = sqrt(prod(target_sz)) * output_sigma_factor / cell_size;
yf = fft2(gaussian_shaped_labels(output_sigma, floor(window_sz / cell_size)));
cos_window = hann(size(yf,1)) * hann(size(yf,2))';
       
param0 = [p(1), p(2), p(3)/sz(2), p(5), p(4)/p(3), 0];
p0 = p(4)/p(3);
param0 = affparam2mat(param0);

param = [];
param.est = param0;  % affine parameter estimation
conf = [];

forMat = '.jpg';
num = init.length;
result = zeros(num, 6);

frame = imread([dataPath '1.jpg']);             %%Load the first frame image
if  size(frame,3) == 3
    framegray = double(rgb2gray(frame))/256;    %%For color images
    img = rgb2gray(frame);
else
    framegray = double(frame)/256;   %%For Gray images
    img = frame;
end
drawopt = drawtrackresult([], 1, frame, sz, param);
result(1,:) = param.est';
[ center fcorners ] = p_to_box(sz, result(1,:));
CenterAll{1}  = center;      
CornersAll{1} = fcorners;

pos = [param.est(2),param.est(1)];
patch = get_subwindowkcf(img, pos, window_sz);
xf = fft2(get_features(patch, features, cell_size, cos_window));
kf = gaussian_correlation(xf, xf, kernel.sigma);
alphaf = yf ./ (kf + lambda);
model_alphaf = alphaf;
model_xf = xf;

%%imge patch
tmpl.mean = warpimg(framegray, param0, sz);   %%mean value 
tmplmeanf = normVector(tmpl.mean(:));
num_p = 10; pos_step = 2;                                                
num_n = 20; neg_step = 4;

[A_pos, A_neg] = affineTrainG(sz, param, num_p, num_n,p0,framegray);
A_pos = normVector(A_pos);
A_neg = normVector(A_neg);

[H_pos,H_neg] = multiHfiter(A_pos,A_neg,num_n,neg_step,pos_step,sz);
H = [H_pos,H_neg];
H(isnan(H)) = 0;

M = size(H,2);
posx.mu = zeros(M,1);% mean of positive features
negx.mu = zeros(M,1);
posx.sig= ones(M,1);% variance of positive features
negx.sig= ones(M,1);
gamma = 0.85;
alpha = 1-0.05;
c_pos = H'*A_pos;
posx.feature = c_pos;
c_neg = H'*A_neg;
negx.feature = c_neg;
[posx.mu,posx.sig,negx.mu,negx.sig] = classiferUpdate(posx,negx,posx.mu,posx.sig,negx.mu,negx.sig,gamma);% update distribution parameters
duration = 0;
sr = opt.numsample;
AA = [A_pos,A_neg];


for f = 2:num
    f%sprintf('#%d',f);
    img_color = imread([dataPath int2str(f) forMat]);
    if size(img_color,3)==3
        img	= double(rgb2gray(img_color))/256;
        imm = rgb2gray(img_color);
    else
        img	= double(img_color)/256;
        imm = img_color;
    end
    tic;
    %[~,Y,param] = affineSample_HOG(double(img), sz, opt, param,cellSize);
    [~,Candidate,param] = affineSample(double(img), sz, opt, param);
    Candidate = normVector(Candidate);
    c_test = H'*Candidate;
    detectx.feature = c_test;
    r = ratioClassifier(posx,negx,detectx);% compute the classifier for all samples
    clf = sum(r);% linearly combine the ratio classifiers in r to the final classifier
    %-------------------------------------
    [~,sortnum] = sort(clf,'descend');
    maxidx = sortnum(1);
    c = clf(maxidx);
    param.est = affparam2mat(param.param(:,maxidx));
    if c < 0 
        patch = get_subwindowkcf(imm, pos, window_sz);
        zf = fft2(get_features(patch, features, cell_size, cos_window));
        kzf = gaussian_correlation(zf, model_xf, kernel.sigma);
        response = real(ifft2(model_alphaf .* kzf)); 
		%target location is at the maximum response
		[row, col] = find(response == max(response(:)), 1);
		%pos = pos - floor(window_sz/2) + [row, col];
        [vert_delta, horiz_delta] = find(response == max(response(:)), 1);
        if vert_delta > size(zf,1) / 2,  %wrap around to negative half-space of vertical axis
            vert_delta = vert_delta - size(zf,1);
        end
        if horiz_delta > size(zf,2) / 2,  %same for horizontal axis
            horiz_delta = horiz_delta - size(zf,2);
        end
        [ psr ] = PSR( response,PSRange);
        pos = pos + cell_size * [vert_delta - 1, horiz_delta - 1];
        param.est = [pos(2);pos(1);param.est(3:end)];
         %param.param = temp;
    end
    %savetrackresult(drawopt, f, img_color, sz, param,savepath);
    drawtrackresult(drawopt, f, img_color, sz, param);
    [posx.mu,posx.sig,negx.mu,negx.sig] = classiferUpdate(posx,negx,posx.mu,posx.sig,negx.mu,negx.sig,gamma);
    %tmpl.mean = warpimg(img, param.est, sz);
    H_posnew = multiHfiterPos(A_pos,pos_step,sz);
    H_posnew(isnan(H_posnew)) = 0;
    if ~isempty(H_posnew)
        H_pos = bsxfun(@plus,alpha*H_pos,(1-alpha)*H_posnew);
    end
    
    temp_best = warpimg(img, param.est, sz);  
    if rem(f,5) == 0        
        [A_pos, A_neg] = affineTrainG(sz, param, num_p, num_n,p0,img);
        A_pos = normVector(A_pos);
        A_neg = normVector(A_neg);
        AA = [tmplmeanf,A_pos,A_neg];
        H_neg = multiHfiterNeg(A_neg,num_n,neg_step,sz);
    end
    H = [H_pos,H_neg];
    H(isnan(H)) = 0;
    pos = [param.est(2),param.est(1)];
    patch = get_subwindowkcf(img, pos, window_sz);
    xf = fft2(get_features(patch, features, cell_size, cos_window));
    kf = gaussian_correlation(xf, xf, kernel.sigma);
    alphaf = yf ./ (kf + lambda);
    model_alphaf = (1 - interp_factor) * model_alphaf + interp_factor * alphaf;
    model_xf = (1 - interp_factor) * model_xf + interp_factor * xf;
    
%     duration = duration + toc;
%     result(f,:) = param.est';
%     [ center fcorners ] = p_to_box(sz, result(f,:));
%     CenterAll{f}  = center;
%     CornersAll{f} = fcorners;
end


% fprintf('%d frames took %.3f seconds : %.3fps\n',f, duration, f/duration);
% fps = f/duration;
% %%******************************************* Save and Display Tracking Results *********************************************%%
% 
% load([ init.respath '\' title '_gt.mat']);
% 
% [ overlapRate ] = overlapEvaluationQuad(CornersAll, gtCornersAll, frameIndex);
% [ centerRate ] = centerErrorEvaluation(CenterAll, gtCenterAll, frameIndex);
% mean(overlapRate)
% save([savepath title '_rs','.mat'], 'CenterAll','CornersAll','centerRate','overlapRate','fps');
%%*************************3.STD Results*****************************************************************************************************************************************%%
%%*************************3.STD Results*****************************************************************************************************************************************%%
% load([ init.respath title '_gt.mat']);
% [ overlapRate ] = overlapEvaluationQuad(me2CornersAll, gtCornersAll, frameIndex);
% mOverlapRate = mean_no_nan(overlapRate)
% [ centerError ] = centerErrorEvaluation(me2CenterAll,  gtCenterAll, frameIndex);
% mCenterError = mean_no_nan(centerError)
