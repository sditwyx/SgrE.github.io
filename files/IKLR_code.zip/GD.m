function [W, iterations, costT, minCost] = GD(W,Y, KT1, K, eta,lambda,h,inexact_param)

n = length(Y);

%% Setting parameter values and initializing counters (eta given by user)
iterations = 0;
minModel = zeros(n,1);
minCost = 1e+11;
costT = 0;
%% Iteratively updating the model using stochastic gradient descent with 1 random point
while 1
    iterations = iterations + 1;
    
    %% Find cost and use the model corresponding to the minimum cost
    costT(iterations) = CostFunction(W, KT1, K,Y,lambda,h);
    costT(iterations) ;
    %if costT(iterations) < minCost
       % minCost = costT(iterations)
        minModel = W; 
    %end
    
    %% Randomly choosing 1 point
    i = randi(n);
    
    %% Computing gradient and updating model
    sigma = Sigma(Y .* (W'*K)');
    %delta = (-K(:,i)*Y(i) + K(:,i)*(Y(i)*sigma(i))) + 2*lambda*KT1*W;
    delta = (-K*Y + K*(Y.*sigma)) + 2*lambda*KT1*W;
    W = W - delta*eta;
    eta = eta * 0.9;
    %if (iterations>1 && norm(costT(iterations)-costT(iterations-1))/norm(costT(iterations))<inexact_param) || (iterations>=1000)
    if (iterations>1 && norm(costT(iterations)-costT(iterations-1))<inexact_param) || (iterations>=1000)
        break;
    end
end
%% Returning model corresponding to the lowest cost
W = minModel;
end

