function [W, iterations, costT, minCost] = SGD(W,Y, KT1, K, eta,lambda,h)
%% StochasticGradientDescent This function finds the optimum model by incrementally updating the model using only 1 random point.

% Y - Vector of desired output values in training set 
% K - gram matrix for training input values
% YT - Vector of desired output values in test set
% KT - gram matrix for test input values
% eta - step size
% costT - test cost iteration by iteration
% W - model after BGD converges
% iterations - number of iterations in which BGD converges

n = length(Y);

%% Setting parameter values and initializing counters
iterations = 0;
minModel = zeros(n,1);
minCost = 1e+11;
delta = ones(n,1);
costT = 0;
%% Iteratively updating the model using stochastic gradient descent with 1 random point
while norm(delta)>1e-3
    iterations = iterations + 1;
    
    %% Find cost and use the model corresponding to the minimum cost
    costT(iterations) = CostFunction(W, KT1, K,Y,lambda,h);

        minModel = W; 
    
    %% Randomly choosing 1 point
    i = randi(n);
    
    %% Computing gradient and updating model
    sigma = Sigma(Y .* (W'*K)');
    delta = (-K(:,i)*Y(i) + K(:,i)*(Y(i)*sigma(i))) + 2*lambda*KT1*W;
    W = W - delta*eta;
    eta = eta * 0.8;
    if (iterations>1 && norm(costT(iterations)-costT(iterations-1))<1e-4) || (iterations>=2000)
        break;
    end
end
%% Returning model corresponding to the lowest cost
W = minModel;
end

