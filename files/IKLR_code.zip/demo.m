close all;
clear all;
title = 'haberman';
rand('state',0);    randn('state',0);
load(['.\data\' title '.mat'])

rate = 0.5;% Traing-test split
eta = 1e-2;
L_fold = 5; %5-fold cross validation
flag_CV = 0;
outer_iternum = 20; %The number of outer iterations
type = 'sgd'; % or 'sgd'
inexact_param = 1; % in GD version: exact: 1e-4; inexct: 1
times = 1;
ACC = zeros(times,1);
PRE = zeros(times,1);
REC = zeros(times,1);
train_time = 0;
test_time = 0;
for kk = 1:times
    
    X_min = repmat(min( X ), [size(X, 1),1]);
    X_max = repmat(max( X ), [size(X, 1),1]);
    X = (X - X_min)./(X_max - X_min);
    
    rate = 1/2;
    Training_num = round(length(Y)*rate);
    [temp, index] = sort(rand( length(Y), 1));
    X_train = X( index( end - Training_num+1 : end), : );
    Y_train = Y( index( end - Training_num+1: end));
    X_test = X( index( 1 : end - Training_num), : );
    Y_test = Y( index( 1 : end - Training_num));
    
    n=size(X_train,1);
    m = size(X_train,2);
    ntest=size(X_test,1);
    y = Y_train;
    
    %---------compute the indefinite kernel matrix--------------%
    kernel_train =  zeros(n,n);
    for i = 1:n
        for j = 1:n
            kernel_train(i,j) = max(0.7*m-norm(X_train(i,:)-X_train(j,:),1),0);
        end
    end
    
    kernel_test = zeros(size(X_test,1),n);
    for i = 1:size(X_test,1)
        for j = 1:n
            kernel_test(i,j) = max(0.7*m-norm(X_test(i,:)-X_train(j,:),1),0);
        end
    end
    
    rho = min(eig(kernel_train));
    if rho < 0
        [U,S] = eig(kernel_train);
        kernel_train1 = U*(S-1.1*rho*eye(size(S,1),size(S,1)))*inv(U);
        kernel_train2 = U*(-1.1*rho*eye(size(S,1),size(S,1)))*inv(U);
    else
        kernel_train1 = kernel_train;
        kernel_train2 = 0;
    end
    
    if flag_CV == 1
        [lambda] = CrossValidate_lambda(y,kernel_train,L_fold,eta);
    else
        lambda = 1e-1;
    end
    beta = rand(n,1);
    
    cost = zeros(1,outer_iternum);
    tic;
    switch type
        case 'gd'
            for j = 1:outer_iternum
                j
                cost(j) = CostFunction(beta, kernel_train,kernel_train, y,lambda,zeros(n,1));
                h = lambda*kernel_train2*beta;
                
                [W, iterations, costT] = GD(beta,Y_train, kernel_train1,kernel_train, eta,lambda,h,inexact_param);
                beta = W;
            end
            
        case 'sgd'
            for j = 1:outer_iternum
                j
                cost(j) = CostFunction(beta, kernel_train1,kernel_train, Y_train,lambda,zeros(n,1));
                h = lambda*kernel_train2*beta;
                [W, iterations, costT] = SGD(beta,Y_train, kernel_train1, kernel_train, eta,lambda,h);
                beta = W;
            end
    end
    
    train_time = train_time + toc;
    tic;
    [accuracy,precision,recall] = Prediction(beta, Y_test, kernel_test);
    test_time = test_time + toc;
    ACC(kk) = accuracy;
    PRE(kk) = precision;
    REC(kk) = recall;
end
train_time_avg = train_time/times;
test_time_avg = test_time/times;
fprintf('ACC=%f��%f\n',mean(ACC),std((ACC)));
fprintf('Training time=%f\n',train_time_avg);