function [cost] = CostFunction( W, KT,K, Y,lambda,h)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
n = length(W);
%cost = - sum(log(Sigma(Y .* (K*W))));
cost = lambda*W'*KT*W -1/n* sum(log(1e-4+Sigma(Y .* (K*W))))-W'*h;
end

