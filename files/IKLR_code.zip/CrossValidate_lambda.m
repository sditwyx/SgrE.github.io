function [C] = CrossValidate_lambda(Y,kernel,L_fold,eta)

N = length(Y);
N_sub = floor(N/L_fold);
N = N_sub *  L_fold;
Y = Y( 1 : N);
%X = X( 1 : N, : );
kernel = kernel(1:N,1:N);


index_sub = Sample_division(N, L_fold);
index_sub = index_sub';

C_set = [1e-4, 1e-3, 1e-2, 1e-1, 0.2,  0.5, 1, 2,5,10]; 
accuracy_vec = zeros(1,length(C_set));
for ss_C = 1 : length(C_set)
    C_temp = C_set(ss_C);
    acc_temp = zeros(1,length(L_fold));
    for ii = 1 : L_fold
        
        index_test = index_sub( :, ii );
        index_train = setdiff( 1 : N, index_test)';
        
        kernel_train = kernel(index_train,index_train);
        kernel_test = kernel(index_test,index_train);
        Y_train = Y(index_train);
        Y_test = Y(index_test);
        n = length(index_train);
        ntest = length(Y_test);
        rho = min(eig(kernel_train));
        if rho < 0
            [U,S] = eig(kernel_train);
            kernel_train1 = U*(S-1.1*rho*eye(size(S,1),size(S,1)))*inv(U);
            kernel_train2 = U*(-1.1*rho*eye(size(S,1),size(S,1)))*inv(U);
        else
            kernel_train1 = kernel_train;
            kernel_train2 = 0;
        end
        beta = rand(n,1);
        for j = 1:20
            %cost(j) = CostFunction(beta, kernel_train,kernel_train, Y_train,C_temp,zeros(n,1));
            h = C_temp*kernel_train2*beta;
            %[W, ~, ~] = SGD(beta,Y_train, kernel_train1, Y_train, kernel_train, eta,C_temp,h);
             [W, ~,~] = GD(beta,Y_train, kernel_train1,kernel_train, eta,C_temp,h,1);
            beta = W;
        end
         [predict] = Prediction(beta, Y_test, kernel_test);
        acc_temp(ii) = predict;
    end
    accuracy_vec(ss_C) = mean(acc_temp);
end
[~,idmax] = max(accuracy_vec);
C = C_set(idmax(1));