function [accuracy,precision,recall] = Prediction(W, Y, gram)
%% Prediction & Misclassification
% Given the optimum model, gram matrix and the desired output
% values the predicted output values are generated and number of
% missclassifications are returned.
%
% W - model
% Y - vector of desired output values
% gram - matrix of input values after applying kernel function
% prediction - vector of predicted output values
% misclassified - number of misclassifications

%% Prediction
prediction = Sigma(gram*W);
prediction(prediction <= 0.5)= -1;
prediction(prediction > 0.5)= 1;

%% Number of Misclassifications
indpos=find(prediction==1);indneg=find(prediction==-1);
truepos=sum(prediction(indpos)==Y(indpos));
trueneg=sum(prediction(indneg)==Y(indneg));
falsepos=sum(prediction(indpos)~=Y(indpos));
falseneg=sum(prediction(indneg)~=Y(indneg));

accuracy=sum(prediction==Y)/length(Y);
if accuracy<.001
    ronny=3;
end
accuracy = sum(prediction==Y)/length(Y);
precision=truepos/(truepos+falsepos);
recall=truepos/(truepos+falseneg);
end