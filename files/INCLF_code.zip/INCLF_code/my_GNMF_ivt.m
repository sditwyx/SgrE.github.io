function [U_final, V_final,err] = my_GNMF_ivt(X,W, options, U, V,alpha,beta)

if ~isfield(options,'maxIter')
    options.maxIter = 1000;
end
if ~isfield(options,'differror')
    options.differror = 1e-5;
end
err = [];
[mFea,nSmp]=size(X);

DCol = full(sum(W,2));
D = spdiags(DCol,0,nSmp-1,nSmp-1);

x = X(:,end);%������
v = V(:,end);%��ʼ��
X_k = X(:,1:end-1);
V_k = V(:,1:end-1);
U_k1 = U;
for i = 1:options.maxIter
    %-----uodate v / V_{k+1}
    temp1 = U_k1'*x + alpha*v*W(end,end) + alpha*V_k*W(:,end);
    temp2 = U_k1'*U_k1*v + alpha*v*D(end,end) + alpha*V_k*D(:,end);%+beta*v.^(-0.5);
    v =v.*temp1./temp2;
    
    %----update U_{k+1}
    temp3 = X_k*V_k' + x*v';
    temp4 = U_k1*V_k*V_k' + U_k1*v*v';
    U = U_k1.*temp3./temp4;
    if norm(U_k1-U)/norm(U) < options.differror 
       break;
    end
    U_k1 = U;
    err(i) = norm(X-U*[V_k,v]);
end
U_final = U;
V_final = [V_k,v];

        