function [U_final, V_final,E_final,err] = mynew_NLCF(X, k, W, options, U, V,lamda,miu,gamma,Err,beta)

if ~isfield(options,'maxIter')
    options.maxIter = 1000;
end
if ~isfield(options,'differror')
    options.differror = 1e-5;
end
[mFea,nSmp]=size(X);

 DCol = full(sum(W,2));
 E = spdiags(DCol,0,nSmp,nSmp);
 if isempty(U)
    U = 1000*abs(rand(mFea,k));
    V = 1000*abs(rand(k,nSmp));
    Err = zeros(mFea,nSmp);
 end
U_old = 1000*abs(rand(mFea,k));

e = ones(size(U,2),size(U,2)) - eye(size(U,2));

c = diag(X'*X);
C= repmat(c,1,k);
C = C';
err = [];
beta1 = 0.5*beta;
for i = 1:options.maxIter
        % ===================== update V ========================
        d = diag(U_old'*U_old);
        D= repmat(d,1,nSmp);
        X_cl = X - Err;
        temp1 = 2*( (miu+1)*U_old'*X_cl + lamda*V*W );
        temp2 = 2*U_old'*U_old*V + miu*(C+D)+2*lamda*V*E;
        V = V.*temp1./temp2;
        V(V==inf)=0;%��V�е�������Ϊ0
        %V(V==0)=1e-8;
        
        
        h = sum(V');%�к�
        H = diag(h);
        % ===================== update U ========================
        temp3 = (miu+1)*X_cl*V';
        temp4 = U_old*V*V'+miu*U_old*H+gamma*U_old*e;
        U = U_old.*temp3./temp4; % 3mk
        U(U==inf)=0;%��V�е�������Ϊ0
        %U(U==0)=1e-8;
        % ===================== update Err =====================
        dis = X - U*V;
        Err = max(abs(dis)-beta1, 0).*sign(dis);
        
        for j = 1:nSmp
            temp = dis(:,j);
            temp1 = sqrt( norm(temp) );
            Err(:,j) = max(0,1-beta1/temp1)*temp; 
        end
        
        % ===================== stop =====================
        if norm(U_old-U)/norm(U) < options.differror
            break;
        end
        U_old = U;
        err(i) = norm(X_cl-U*V);
 
end
U_final = U;
V_final = V;
E_final = Err;
