function [V,err] = gradV(X,U,miu)
[~,nSmp]=size(X);
k=size(U,2);
V_old = abs(rand(k,nSmp));
c = diag(X'*X);
C= repmat(c,1,k);
C = C';
err = [];
d = diag(U'*U);
D= repmat(d,1,nSmp);
temp1 = 2*( (miu+1)*U'*X );
for i = 1:300
        % ===================== update V ========================
        temp2 = 2*U'*U*V_old + miu*(C+D);
        V = V_old.*temp1./temp2;
        %V(V==inf)=0;%��V�е�������Ϊ0
        V(isnan(V)) = 0;
        if norm(V_old-V)/norm(V) < 10e-3
            break;
        end
        V_old = V;
        err(i) = norm(X-U*V);
end