%*************************************************************
%% Copyright (C).
%% All rights reserved.
%% Date: 07/2015

%%******************************************* Experimental Settings *********************************************%%

clc;
clear all;
warning all;
addpath('./Affine Sample Functions');
addpath('./images');
addpath(genpath('./Evaluation'));
savepath = ['Results\'];

%-----------DATASET PARAMETER------------------%
init.p   = [353.5, 37.5, 95, 65,0];
init.name = 'Deer';
dataPath = ['.\Deer\img\'];      
init.length = 71;
init.opt  = struct('numsample',600, 'condenssig',0.25, 'ff',1,'batchsize',5, 'affsig',[12,12,.000,.000,.000,.000]);
%------------------------------------------------------------------------%

p = init.p;
title = init.name;                                                % initial position and affine parameters
%mkdir(['images\' title]);

rand('state',0);    randn('state',0);
opt = init.opt;
opt.tmplsize = [32 32];                                          
sz = opt.tmplsize;
n_sample = opt.numsample;
condx = [];
if ~isfield(opt,'maxbasis')   opt.maxbasis = 16;  end                       
options = [];
param0 = [p(1), p(2), p(3)/sz(2), p(5), p(4)/p(3), 0];
p0 = p(4)/p(3);
param0 = affparam2mat(param0);

param = [];
param.est = param0;                               
conf = [];

forMat = '.jpg';
num = init.length;
result = zeros(num, 6);

frame = imread([dataPath '1.jpg']);             %%Load the first frame image
if  size(frame,3) == 3
    framegray = double(rgb2gray(frame))/256;    %%For color images
else
    framegray = double(frame)/256;   %%For Gray images
end
drawopt = drawtrackresult([], 1, frame, sz, param);
result(1,:) = param.est';
[ center fcorners ] = p_to_box(sz, result(1,:));
CenterAll{1}  = center;      
CornersAll{1} = fcorners;


tmpl.mean = warpimg(framegray, param0, opt.tmplsize);   
param.wimg = tmpl.mean;                       
wimgs = param.wimg(:);

num_p = 49;                                                
num_n = 100;
[A_pos, A_neg] = affineTrainG(dataPath, sz, opt, param, num_p, num_n, forMat, p0,1);
A_pos = [wimgs,A_pos];
Wk = [];
Hk = [];
k = 16;
n = 2;
duration = 0;
%savepath = ['images\',title '\'];
U = [];
V = [];
E = [];
buff = [wimgs];
 num_p1 = 10; num_n1 = 20;
 begin_frame = 5;
 for f = 2:begin_frame
    img_color = imread([dataPath int2str(f) forMat]);
    if size(img_color,3)==3
        img	= double(rgb2gray(img_color))/256;
    else
        img	= double(img_color)/256;
    end
    param = do_simple_track(img, tmpl, param, opt);
    [A1_pos, A1_neg] = affineTrainG(dataPath, sz, opt, param, num_p1, num_n1, forMat, p0,f);
    A_pos = [A_pos,A1_pos];
    A_neg = [A_neg,A1_neg];
    result(f,:) = param.est';
    tmpl.mean = warpimg(img, param.est, opt.tmplsize);
    [ center fcorners ] = p_to_box(sz, result(f,:));
    CenterAll{f}  = center;      
    CornersAll{f} = fcorners;
    %savetrackresult(drawopt, f, img_color, sz, param,savepath);
    drawtrackresult(drawopt, f, img_color, sz, param);
    buff = [buff,tmpl.mean(:)];
 end
[ L,W] = constructL(A_pos);
lambda = 1; beta = 1; gamma = 0.001; miu = 0.001;
tic
[Wk, Hk,E,err] = mynew_NLCF(A_pos, k, W, options, U, V,lambda,miu,gamma,E,beta);%lamdaͼ��beta:������gamma:������miu:local sparsity
toc
rerr = [];
%-------------SVm Train
% c_pos = mexLasso(Wk, A_pos, paramSR);
% c_pos = full(c_pos);
% c_neg = mexLasso(Wk, A_neg, paramSR);
miu1 = 0.1;
c_pos = gradV(Wk,A_pos,miu1);
c_neg = gradV(Wk,A_neg,miu1);
c_train = [c_pos;c_neg];
label = [ones(size(A_pos,2),1);zeros(size(A_neg,2),1)];
SVMstruct=svmtrain(c_train,label,'Kernel_Function','rbf'); %matlab
%SVMstruct = svmtrain(label,c_train,'-t 2');%libsvm

for f = begin_frame+1:num
    f%sprintf('#%d',f);
    img_color = imread([dataPath int2str(f) forMat]);
    if size(img_color,3)==3
        img	= double(rgb2gray(img_color))/256;
    else
        img	= double(img_color)/256;
    end
    tic;
    [~,Y,param] = affineSample(double(img), sz, opt, param);
    %YY = normVector(Y);                                             % normalization
    
    %---------------SVM test------------------------------------------
    %c_test = mexLasso(Wk, Y, paramSR);
    [c_test,errinv] = gradV(Wk,Y,miu1);
    %[c_test,errinv] = gradV(Y,Wk,miu1);
    %c_test = c_test';
    
    class=svmclassify(SVMstruct,c_test);%matlab
     %[class, ~, ~] = svmpredict(ones(1,size(c_test,1)), c_test, SVMstruct);%libsvm
    
    [col_temp,~] = find(class==1);%
    conf(f-begin_frame)=length(col_temp);
    if length(col_temp) ~= 0
        Y_candidate = Y(:,col_temp);
    else 
        Y_candidate = Y;
    end
    M = EuDist2(Y_candidate',(Wk*Hk)',0);
    temp = min(min(M));
    [max_idx,~] = find(M==temp);
    if length(max_idx)>1
        max_idx = max_idx(1);
    end
    rerr = [rerr,temp];
    if length(col_temp) ~= 0
    param.est = affparam2mat(param.param(:,col_temp(max_idx)));
    else 
        param.est = affparam2mat(param.param(:,max_idx));
    end
    tmpl.mean = [];
    tmpl.mean = warpimg(img, param.est, opt.tmplsize);   %%
    
    result(f,:) = param.est';
    [ center fcorners ] = p_to_box(sz, result(f,:));
     CenterAll{f}  = center;      
    CornersAll{f} = fcorners;
    %savetrackresult(drawopt, f, img_color, sz, param,savepath);
    drawtrackresult(drawopt, f, img_color, sz, param);
    buff = [buff,tmpl.mean(:)];
    update = 10;
    if rem(f,update) == 0
        [~,numk] = min(rerr);
        if f <= update
           candidate = buff(:,numk+begin_frame);
        else
           candidate = buff(:,numk);
        end
        col = size(A_pos,2);
        candi = repmat(candidate,1,col-1);
        A_pos_new = A_pos(:,2:end);
        Subtitute_dis = EuDist2(candi',A_pos_new',0);%
        dis = Subtitute_dis(1,:);%
        [~,id] = min(dis);
        A_pos(:,id) = candidate;%
        
        temp1 = A_pos(:,end);
        A_pos(:,end) = A_pos(:,id);
        A_pos(:,id) = temp1;
        
        temp2 = Hk(:,end);
        Hk(:,end) = Hk(:,id);
        Hk(:,id) = temp2;
        %--
        temp3 = E(:,end);
        E(:,end) = E(:,id);
        E(:,id) = temp3;
        %-------------------------------------------------------------
        [~,W_new] = constructL(A_pos(:,1:end-1));
        [Wk, Hk,E,err1] = mynew_NLCF_ivt(A_pos,W_new, options, Wk, Hk,E,lambda,miu,gamma,beta);
        %[Wk, Hk,err1] = my_NLCF_ivt(A_pos,W_new, options, Wk, Hk,lambda,miu,gamma,beta);
        condx = [condx,cond(Y,2)];
        %--------------SVM Train
        c_pos = gradV(Wk,A_pos,miu1);
        c_train = [c_pos;c_neg];
        label = [ones(size(A_pos,2),1);zeros(size(A_neg,2),1)];
        SVMstruct=svmtrain(c_train,label,'Kernel_Function','rbf'); %,matlab
        %SVMstruct = svmtrain(label,c_train,'-t 2');%libsvm
        
        buff = [];
        rerr = [];
    end
    duration = duration + toc;
end

fprintf('%d frames took %.3f seconds : %.3fps\n',(f-begin_frame), duration, (f-begin_frame)/duration);
fps = (f-begin_frame)/duration;
%%******************************************* Save and Display Tracking Results *********************************************%%

%save([savepath title '_me2_rs','.mat'], 'CenterAll','CornersAll','fps');

