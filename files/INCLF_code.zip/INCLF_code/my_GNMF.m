function [U_final, V_final,err] = my_GNMF(X, k, W, options, U, V,alpha)

if ~isfield(options,'maxIter')
    options.maxIter = 1000;
end
if ~isfield(options,'differror')
    options.differror = 1e-5;
end
[mFea,nSmp]=size(X);

 DCol = full(sum(W,2));
 D = spdiags(DCol,0,nSmp,nSmp);
 if isempty(U)
    U = abs(rand(mFea,k));
    V = abs(rand(k,nSmp));
 end
U_old = abs(rand(mFea,k));
err = [];
e = ones(size(U,2),size(U,2)) - eye(size(U,2));
for i = 1:options.maxIter
        % ===================== update V ========================
        temp1 = U_old'*X + alpha*V*W;
        temp2 = U_old'*U_old*V + alpha*V*D;%+beta*V.^(-0.5);
        V = V.*temp1./temp2;

        % ===================== update U ========================
        temp1 = X*V';
        temp2 = U_old*V*V';%+gamma*U_old*e;
        U = U_old.*temp1./temp2; % 3mk
        if norm(U_old-U)/norm(U) < options.differror
            break;
        end
        U_old = U;
        err(i) = norm(X-U*V);
end
U_final = U;
V_final = V;
