function [U_final, V_final,Err,err] = mynew_NLCF_ivt(X,W, options, U, V,Err,lamda,miu,gamma,beta)

if ~isfield(options,'maxIter')
    options.maxIter = 1000;
end
if ~isfield(options,'differror')
    options.differror = 1e-5;
end
gamma1 = 0.5*gamma;
beta1 = beta*0.5;
miu1 = 0.5*miu;
[~,nSmp]=size(X);

DCol = full(sum(W,2));
D = spdiags(DCol,0,nSmp-1,nSmp-1);

err = [];
x = X(:,end);%������
dis = Err(:,end);%��Ӧ������
dis(:,:)=0;
v = V(:,end);%��ʼ��
%v = abs(rand(size(V,1),1));
X_k = X(:,1:end-1);
V_k = V(:,1:end-1);
E_k = Err(:,1:end-1);
U_k1 = U;
e = ones(size(U,2),size(U,2)) - eye(size(U,2));
for i = 1:options.maxIter
    %-----uodate v / V_{k+1}
    temp1 = (miu+1)*U_k1'*(x-dis) + lamda*v*W(end,end) + lamda*V_k*W(:,end) - miu1*ones(size(V_k,1),1)*(x-dis)'*(x-dis);
    temp2 = U_k1'*U_k1*v + lamda*v*D(end,end) + lamda*V_k*D(:,end) +miu1*diag(U_k1'*U_k1);%+ beta1*v.^(-0.5);
    v =v.*temp1./temp2;
    v(v==inf)=0;%��V�е�������Ϊ0
    v(v==0)=1e-8;
    
    %----update U_{k+1}
    temp3 = (miu+1) * (X_k*V_k' + (x-dis)*v');
    H_k = diag(sum(V_k'));
    temp4 = U_k1*V_k*V_k' + U_k1*v*v'+miu*U_k1*H_k +U_k1*diag(v) +gamma1*U_k1*(e+e');
    U = U_k1.*temp3./temp4;
    U(U==inf)=0;%��V�е�������Ϊ0
    U(U==0)=1e-8;
    
    %-----update Err
    temp = x - U*v;
    dis = max(0,abs(temp)-beta1).*sign(temp);
    %temp1 = sqrt( norm(temp) );
    %dis = max(0,1-beta1/temp1)*temp;
    
    if norm(U_k1-U)/norm(U) < options.differror 
       break;
    end
    U_k1 = U;
    err(i) = norm(X-U*[V_k,v]);
end
U_final = U;
V_final = [V_k,v];
Err = [E_k,dis];

        